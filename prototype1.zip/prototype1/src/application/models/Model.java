package application.models;

public class Model {

}
